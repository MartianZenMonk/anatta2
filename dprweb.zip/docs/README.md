# Sphinx Documentation Generation

## Install Dependencies

    pip install --requirement requirements.txt

## Generate English Documentation

    make html

## Manage Translations

See https://docs.readthedocs.io/en/stable/guides/manage-translations.html.
