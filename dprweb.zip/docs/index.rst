Digital Pāli Reader Docs
===============================================

.. toctree::
   :maxdepth: 1
   :caption: Getting Started

   pages/welcome-to-dpr
