module.exports = {
  coveragePathIgnorePatterns: ['<rootDir>/en/cped/index.js'],
  roots: ['_dprhtml/'],
  setupFilesAfterEnv: ['./jest.setup.js'],
}
